import myLibraries
from myLibraries import *
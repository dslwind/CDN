import newGameLib
from newGameLib import *
import Blender	

	
	
def xsmParser(filename,g):
	#g.debug=True
	g.word(4)  
	chunk=g.B(4)	
	if chunk[2]==1:g.endian='>'
	if chunk[2]==0:g.endian='<'
	g.H(14)
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	g.word(g.i(1)[0])
	num = 0
	
	action=Action()
	action.name=g.basename
	action.BONESPACE=True
	action.BONESORT=True
	
	while(True):
		data = g.i(3)
		back = g.tell()
		if data[0]==202:
			bones_count=g.i(1)[0]
			for m in range(bones_count):
				t=g.tell()
				g.f(20)
				data1=g.i(4)
				g.seek(t+100)
				name=g.word(g.i(1)[0])
				print name
				abone=ActionBone()
				abone.name=name
				
				for i in range(data1[0]):	 
					loc = g.f(3)
					posmatrix=VectorMatrix(loc)
					abone.posKeyList.append(posmatrix)
					time =  int(g.f(1)[0]*30)
					abone.posFrameList.append(time)
				for i in range(data1[1]):
					rotmatrix=QuatMatrix(g.short(4,'h',15)).resize4x4()	
					abone.rotKeyList.append(rotmatrix)
					time =  int(g.f(1)[0]*30)					
					abone.rotFrameList.append(time)	
					
				for i in range(data1[2]):
					g.f(3),round(g.f(1)[0]*30,0)
				for i in range(data1[3]):
					g.h(4),round(g.f(1)[0]*30,0)					
				action.boneList.append(abone)
		else:break		
		if g.tell()==g.fileSize():break 
	action.draw() 
	action.setContext()
	
	
	
def parseModel(g):
	print
	print '='*30,'MODEL'
	print
	model=Model()
	meshList=[]
	skinList=[]				
	vertPosList=[]
	vertUVList=[]
	skinIDList=[]
	indiceList=[]
	model.skinIndiceList=[]
	model.skinWeightList=[]	
	
	A=g.i(9)
	print A
	model.ID=A[0]
	model.skinVertCount=A[2]	
	for n in range(A[6]):
		B=g.i(2)
		print B,g.tell()
		if B[0]==0:#position 
			g.H(2)
			for m in range(A[3]):vertPosList.append(g.f(3))
		elif B[0]==1:#normals 
			g.H(2)
			for m in range(A[3]):g.f(3) 
		elif B[0]==3:#uv
			g.H(2)
			for m in range(A[3]):
				u,v=g.f(2)
				if u>=0:vertUVList.append([u,v])
				else:vertUVList.append([-u,v])
		elif B[0]==2:
			g.H(2)
			for m in range(A[3]):g.f(4)
		#elif B[0]==4:
		#	for m in range(A[3]):indiceList.append(g.i(1)[0])
		elif B[0]==4:
			for m in range(A[3]):skinIDList.append(g.i(1)[0])	
		#elif B[0]==36:
		#	g.H(2)
		#	for m in range(A[3]):g.seek(12,1)	
		else:
			print 'unknow',B
			break
	#g.debug=True
	vertIDStart=0		
	for i in range(A[5]):
		mesh=Mesh()
		w = g.i(4)	
		print 'mat:',i,w
		mesh.indiceList=g.i(w[0])
		mesh.vertPosList=vertPosList[vertIDStart:vertIDStart+w[1]]
		mesh.vertUVList=vertUVList[vertIDStart:vertIDStart+w[1]]
		mesh.skinVertIDList=skinIDList[vertIDStart:vertIDStart+w[1]]
		mesh.vertIDStart=vertIDStart
		mesh.ID=w[0]
		boneMap=g.i(w[3]) 
		mat=Mat()
		mat.diffuse=matList[w[2]].diffuse
		mat.specular=matList[w[2]].specular
		mat.TRIANGLE=True
		mat.ZTRANS=True
		mesh.matList.append(mat)
		vertIDStart+=w[1]
		model.meshList.append(mesh)
	modelList.append(model)	
	g.tell()
	
	
def parseSkin(g):
	print
	print 'skin',g.tell()
	print
	w = g.i(5)	
	t=g.tell()
	g.seek(w[3]*8,1)
	for model in modelList:
		if model.ID==w[0]:
			print w,model.skinVertCount
			model.listA=[]
			for i in range(model.skinVertCount):
				model.listA.append(g.i(2))
			tt=g.tell()	
			g.seek(t)
			for i in range(model.skinVertCount):
				indiceList=[]
				weightList=[]
				for j in range(model.listA[i][1]):
					weightList.append(g.f(1)[0])
					indiceList.append(g.i(1)[0])							
				model.skinIndiceList.append(indiceList)
				model.skinWeightList.append(weightList)
	
	
class Model:
	def __init__(self):
		self.meshList=[]
	
def xacParser(filename,g):	
	global skeleton
	global matList
	global modelList
	
	g.debug=False
		
	
	skeleton=Skeleton()
	skeleton.name='armature'
	skeleton.BONESPACE=True
	skeleton.DEL=True
	skeleton.NICE=True
	#skeleton.IK=True
	
	modelList=[]
	matList=[]
	
	g.word(4) 
	g.seek(44,1)
	g.word(g.i(1)[0])
	g.i(1),g.tell()
	while(True):
			data = g.i(3)
			back = g.tell()
			print data,back
			if data[0]==8:g.i(4)
			elif data[0]==3:
				print
				mat=Mat()
				g.f(22)
				g.word(g.i(1)[0])
				texID=0
				while(True):					
					unk=g.f(1)[0]
					print unk
					if 0.1<=unk<=2.0:
						g.f(4)
						g.H(4)
						imageName=g.word(g.i(1)[0])+'.dds'
						print texID,imageName
						if texID==0:mat.diffuse=g.dirname+os.sep+imageName
						if texID==1:mat.specular=g.dirname+os.sep+imageName
						texID+=1
					else:
						g.seek(-4,1)
						break	
				matList.append(mat)	
			elif data[0]==11:
				boneCount=g.i(1)[0]
				g.i(1)
				for m in range(boneCount):
					bone=Bone()
					t=g.tell()
					bone.rotMatrix=QuatMatrix(g.f(4)).resize4x4()
					g.seek(16,1)
					bone.posMatrix=VectorMatrix(g.f(4))
					g.seek(t+68)
					w=g.i(4)
					bone.parentID=w[2]
					g.seek(t+156)
					bone.name=g.word(g.i(1)[0])[-27:]
					skeleton.boneList.append(bone)
			elif data[0]==1:parseModel(g)
			elif data[0]==2:parseSkin(g)					
			else:data4 = g.i(3)
				
			if data[0]!=3:	
				g.seek(back + data[1],0)   
			if g.tell()==g.fileSize():
				break
			
 
	print 'SKELETON'
	skeleton.draw()
	print 'MODEL'
	for model in modelList:
		for mesh in model.meshList:
			if len(model.skinIndiceList)>0:
				for id in mesh.skinVertIDList:
					mesh.skinIDList.append([1])
					mesh.skinIndiceList.append(model.skinIndiceList[id])
					mesh.skinWeightList.append(model.skinWeightList[id])
				skin=Skin()	
				skin.boneMap=skeleton.boneNameList
				mesh.skinList.append(skin)
				print len(mesh.vertPosList),len(mesh.skinIndiceList),len(mesh.skinWeightList)
				mesh.BINDSKELETON=skeleton.name	
				mesh.draw()
	g.debug=True
	g.tell()	

	
def Parser():	
	filename=input.filename
	print
	print filename
	print
	ext=filename.split('.')[-1].lower()	
	
	if ext=='xsm':
		file=open(filename,'rb')
		g=BinaryReader(file)
		xsmParser(filename,g)
		#except:pass
		file.close()
	
	if ext=='xac':
		file=open(filename,'rb')
		g=BinaryReader(file)
		xacParser(filename,g)
		file.close()
 
def openFile(flagList):
	global input,output
	input=Input(flagList)
	output=Output(flagList)
	parser=Parser()
	
Blender.Window.FileSelector(openFile,'import','Gujian 2 Online files: *.xac - model, *.xsm - animation') 
	